//Developed by Darron Anderson
#include <stdio.h>

void chessboardDefine(int x,int y);
void makeAMove(int xPos,int yPos,int xMax,int yMax);
void visit(int xPos, int yPos);
void unvisit(int xPos, int yPos);
