#ifndef COMBAT_H
#define COMBAT_H
void do_combat(dungeon *d, character *atk, character *def);
#endif
